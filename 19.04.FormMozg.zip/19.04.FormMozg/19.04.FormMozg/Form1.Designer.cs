﻿
namespace FormMozg
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnJobb = new System.Windows.Forms.Button();
            this.btnFel = new System.Windows.Forms.Button();
            this.btnFelul = new System.Windows.Forms.Button();
            this.btnJobbszel = new System.Windows.Forms.Button();
            this.btnLe = new System.Windows.Forms.Button();
            this.btnAlul = new System.Windows.Forms.Button();
            this.btnkozep = new System.Windows.Forms.Button();
            this.btnBalra = new System.Windows.Forms.Button();
            this.btnBalszel = new System.Windows.Forms.Button();
            this.gpbAtlatszo = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnOpCsok = new System.Windows.Forms.Button();
            this.btnOpNo = new System.Windows.Forms.Button();
            this.gpbMeret = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCsok = new System.Windows.Forms.Button();
            this.btnMeretNo = new System.Windows.Forms.Button();
            this.gpbAtlatszo.SuspendLayout();
            this.gpbMeret.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnJobb
            // 
            this.btnJobb.Location = new System.Drawing.Point(393, 211);
            this.btnJobb.Name = "btnJobb";
            this.btnJobb.Size = new System.Drawing.Size(82, 29);
            this.btnJobb.TabIndex = 0;
            this.btnJobb.Text = "Jobbra";
            this.btnJobb.UseVisualStyleBackColor = true;
            this.btnJobb.Click += new System.EventHandler(this.btnJobb_Click);
            // 
            // btnFel
            // 
            this.btnFel.Location = new System.Drawing.Point(299, 163);
            this.btnFel.Name = "btnFel";
            this.btnFel.Size = new System.Drawing.Size(82, 29);
            this.btnFel.TabIndex = 0;
            this.btnFel.Text = "Fel";
            this.btnFel.UseVisualStyleBackColor = true;
            this.btnFel.Click += new System.EventHandler(this.btnFel_Click);
            // 
            // btnFelul
            // 
            this.btnFelul.Location = new System.Drawing.Point(299, 110);
            this.btnFelul.Name = "btnFelul";
            this.btnFelul.Size = new System.Drawing.Size(82, 29);
            this.btnFelul.TabIndex = 0;
            this.btnFelul.Text = "Felülre";
            this.btnFelul.UseVisualStyleBackColor = true;
            this.btnFelul.Click += new System.EventHandler(this.btnFelul_Click);
            // 
            // btnJobbszel
            // 
            this.btnJobbszel.Location = new System.Drawing.Point(487, 211);
            this.btnJobbszel.Name = "btnJobbszel";
            this.btnJobbszel.Size = new System.Drawing.Size(82, 29);
            this.btnJobbszel.TabIndex = 0;
            this.btnJobbszel.Text = "Jobbszélre";
            this.btnJobbszel.UseVisualStyleBackColor = true;
            this.btnJobbszel.Click += new System.EventHandler(this.btnJobbszel_Click);
            // 
            // btnLe
            // 
            this.btnLe.Location = new System.Drawing.Point(299, 269);
            this.btnLe.Name = "btnLe";
            this.btnLe.Size = new System.Drawing.Size(82, 29);
            this.btnLe.TabIndex = 0;
            this.btnLe.Text = "Lefele";
            this.btnLe.UseVisualStyleBackColor = true;
            this.btnLe.Click += new System.EventHandler(this.btnLe_Click);
            // 
            // btnAlul
            // 
            this.btnAlul.Location = new System.Drawing.Point(299, 322);
            this.btnAlul.Name = "btnAlul";
            this.btnAlul.Size = new System.Drawing.Size(82, 29);
            this.btnAlul.TabIndex = 0;
            this.btnAlul.Text = "Alulra";
            this.btnAlul.UseVisualStyleBackColor = true;
            this.btnAlul.Click += new System.EventHandler(this.btnAlul_Click);
            // 
            // btnkozep
            // 
            this.btnkozep.Location = new System.Drawing.Point(299, 211);
            this.btnkozep.Name = "btnkozep";
            this.btnkozep.Size = new System.Drawing.Size(82, 29);
            this.btnkozep.TabIndex = 0;
            this.btnkozep.Text = "Középre";
            this.btnkozep.UseVisualStyleBackColor = true;
            this.btnkozep.Click += new System.EventHandler(this.btnkozep_Click);
            // 
            // btnBalra
            // 
            this.btnBalra.Location = new System.Drawing.Point(205, 211);
            this.btnBalra.Name = "btnBalra";
            this.btnBalra.Size = new System.Drawing.Size(82, 29);
            this.btnBalra.TabIndex = 0;
            this.btnBalra.Text = "Balra";
            this.btnBalra.UseVisualStyleBackColor = true;
            this.btnBalra.Click += new System.EventHandler(this.btnBalra_Click);
            // 
            // btnBalszel
            // 
            this.btnBalszel.Location = new System.Drawing.Point(111, 211);
            this.btnBalszel.Name = "btnBalszel";
            this.btnBalszel.Size = new System.Drawing.Size(82, 29);
            this.btnBalszel.TabIndex = 0;
            this.btnBalszel.Text = "Balszélre";
            this.btnBalszel.UseVisualStyleBackColor = true;
            this.btnBalszel.Click += new System.EventHandler(this.btnBalszel_Click);
            // 
            // gpbAtlatszo
            // 
            this.gpbAtlatszo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.gpbAtlatszo.Controls.Add(this.label2);
            this.gpbAtlatszo.Controls.Add(this.btnOpCsok);
            this.gpbAtlatszo.Controls.Add(this.btnOpNo);
            this.gpbAtlatszo.Location = new System.Drawing.Point(170, 381);
            this.gpbAtlatszo.Name = "gpbAtlatszo";
            this.gpbAtlatszo.Size = new System.Drawing.Size(381, 57);
            this.gpbAtlatszo.TabIndex = 1;
            this.gpbAtlatszo.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(6, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Átlátszóság: ";
            // 
            // btnOpCsok
            // 
            this.btnOpCsok.Location = new System.Drawing.Point(223, 19);
            this.btnOpCsok.Name = "btnOpCsok";
            this.btnOpCsok.Size = new System.Drawing.Size(82, 29);
            this.btnOpCsok.TabIndex = 0;
            this.btnOpCsok.Text = "Csökken";
            this.btnOpCsok.UseVisualStyleBackColor = true;
            // 
            // btnOpNo
            // 
            this.btnOpNo.Location = new System.Drawing.Point(129, 19);
            this.btnOpNo.Name = "btnOpNo";
            this.btnOpNo.Size = new System.Drawing.Size(82, 29);
            this.btnOpNo.TabIndex = 0;
            this.btnOpNo.Text = "Növekszik";
            this.btnOpNo.UseVisualStyleBackColor = true;
            this.btnOpNo.Click += new System.EventHandler(this.btnOpNo_Click);
            // 
            // gpbMeret
            // 
            this.gpbMeret.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.gpbMeret.Controls.Add(this.label1);
            this.gpbMeret.Controls.Add(this.btnCsok);
            this.gpbMeret.Controls.Add(this.btnMeretNo);
            this.gpbMeret.Location = new System.Drawing.Point(170, 12);
            this.gpbMeret.Name = "gpbMeret";
            this.gpbMeret.Size = new System.Drawing.Size(381, 57);
            this.gpbMeret.TabIndex = 1;
            this.gpbMeret.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Méret";
            // 
            // btnCsok
            // 
            this.btnCsok.Location = new System.Drawing.Point(223, 16);
            this.btnCsok.Name = "btnCsok";
            this.btnCsok.Size = new System.Drawing.Size(82, 29);
            this.btnCsok.TabIndex = 0;
            this.btnCsok.Text = "Csökken";
            this.btnCsok.UseVisualStyleBackColor = true;
            this.btnCsok.Click += new System.EventHandler(this.btnCsok_Click);
            // 
            // btnMeretNo
            // 
            this.btnMeretNo.Location = new System.Drawing.Point(129, 16);
            this.btnMeretNo.Name = "btnMeretNo";
            this.btnMeretNo.Size = new System.Drawing.Size(82, 29);
            this.btnMeretNo.TabIndex = 0;
            this.btnMeretNo.Text = "Növekszik";
            this.btnMeretNo.UseVisualStyleBackColor = true;
            this.btnMeretNo.Click += new System.EventHandler(this.btnMeretNo_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.gpbMeret);
            this.Controls.Add(this.gpbAtlatszo);
            this.Controls.Add(this.btnBalszel);
            this.Controls.Add(this.btnBalra);
            this.Controls.Add(this.btnkozep);
            this.Controls.Add(this.btnAlul);
            this.Controls.Add(this.btnLe);
            this.Controls.Add(this.btnJobbszel);
            this.Controls.Add(this.btnFelul);
            this.Controls.Add(this.btnFel);
            this.Controls.Add(this.btnJobb);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Form mozgatás";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gpbAtlatszo.ResumeLayout(false);
            this.gpbAtlatszo.PerformLayout();
            this.gpbMeret.ResumeLayout(false);
            this.gpbMeret.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnJobb;
        private System.Windows.Forms.Button btnFel;
        private System.Windows.Forms.Button btnFelul;
        private System.Windows.Forms.Button btnJobbszel;
        private System.Windows.Forms.Button btnLe;
        private System.Windows.Forms.Button btnAlul;
        private System.Windows.Forms.Button btnkozep;
        private System.Windows.Forms.Button btnBalra;
        private System.Windows.Forms.Button btnBalszel;
        private System.Windows.Forms.GroupBox gpbAtlatszo;
        private System.Windows.Forms.Button btnOpCsok;
        private System.Windows.Forms.Button btnOpNo;
        private System.Windows.Forms.GroupBox gpbMeret;
        private System.Windows.Forms.Button btnCsok;
        private System.Windows.Forms.Button btnMeretNo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

